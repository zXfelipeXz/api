import express, { Request, Response } from "express";
import { getBankData } from "./conexaoFront";

// Rota para receber as informações do frontend e retornar os dados processados
const app = express();
const port = 4000;

// Middleware para parsing de JSON no corpo das requisições
app.use(express.json());

// Rota para receber as informações do frontend e retornar os dados processados
app.post("/dados-banco", (req: Request, res: Response) => {
  (async () => {
    const { banco, periodo } = req.body;
    try {
      const result = await getBankData({ banco, periodo });
      if (result.success) {
        return res.status(200).json(result.data);
      }
      return res.status(404).json({ message: result.message });
    } catch (error) {
      console.error("Erro:", error);
      return res.status(500).send("Erro no servidor.");
    }
  })();
});

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});
