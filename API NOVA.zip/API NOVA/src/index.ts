import axios, { AxiosError } from "axios";
import { connectToDatabase, saveApiResponse } from "./database";
import { bankData } from "./banksData";
import { getBankData } from "./conexaoFront"; 

const API_URL = "https://homologacao.plugboleto.com.br/api/v1/boletos/lote";
const HEADERS = {
  "Content-Type": "application/json",
  "cnpj-sh": "12067625000150",
  "token-sh": "a60c428fbfcafa73bc8eda5e9b7fee4e",
  "cnpj-cedente": "78839345000120",
};

async function sendBoleto(banco: string) {
  const boletos = bankData[banco];

  if (!boletos) {
    console.error(`Banco ${banco} não encontrado.`);
    return;
  }

  const startTime = Date.now(); 

  try {
    const response = await axios.post(API_URL, boletos, { headers: HEADERS });

    const duration = Date.now() - startTime; 
    const status = response.status;
    const isPositive = [200, 400, 401, 403, 422].includes(status);

    const db = await connectToDatabase();
    await saveApiResponse(db, {
      banco,
      status,
      duration,
      isPositive,
      date: new Date().toISOString(),
    });

    console.log(`Requisição para ${banco} finalizada com sucesso! Tempo de resposta: ${duration}ms`);
  } catch (error) {
    const isPositive = false;
    const axiosError = error as AxiosError;
    const duration = Date.now() - startTime;

    const db = await connectToDatabase();
    await saveApiResponse(db, {
      banco,
      status: axiosError.response?.status || "ECONRESET",
      duration,
      isPositive,
      date: new Date().toISOString(),
    });

    console.error(`Erro ao enviar boleto para ${banco}:`, axiosError.message, `Tempo de tentativa: ${duration}ms`);
  }
}

// Criar uma lista de promessas para todos os bancos
const bancos = [
  "Banco do Brasil", "Itaú", "Caixa", "SicoobV2", "SicoobV3", "SicrediV2",
  "SicrediV3", "Banco Santander", "Banrisul", "Inter"
];

// Aguardar todas as promessas de envio de boletos
async function sendAllBoletos() {
  const boletoPromises = bancos.map(banco => sendBoleto(banco));
  await Promise.all(boletoPromises);  
  console.log("Todas as requisições foram finalizadas!");
}

sendAllBoletos();

// Aqui você pode importar o arquivo do servidor para iniciar o servidor Express.
import "./server";
