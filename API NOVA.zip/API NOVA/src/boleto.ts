export interface Boleto {
  CedenteContaNumero: string;
  CedenteContaNumeroDV: string;
  CedenteConvenioNumero: string;
  CedenteContaCodigoBanco: string;
  SacadoCPFCNPJ: string;
  SacadoEmail: string;
  SacadoEnderecoNumero: string;
  SacadoEnderecoBairro: string;
  SacadoEnderecoCEP: string;
  SacadoEnderecoCidade: string;
  SacadoEnderecoComplemento: string;
  SacadoEnderecoLogradouro: string;
  SacadoEnderecoPais: string;
  SacadoEnderecoUF: string;
  SacadoNome: string;
  SacadoTelefone: string;
  SacadoCelular: string;
  TituloDataEmissao: string;
  TituloDataVencimento: string;
  TituloMensagem01: string;
  TituloMensagem02: string;
  TituloMensagem03: string;
  TituloNossoNumero: string;
  TituloNumeroDocumento: string;
  TituloValor: string;
  TituloLocalPagamento: string;
}
