import { Pool } from "pg";
import * as config from "../config/config.json";

// Define o tipo da estrutura do arquivo config.json
interface DbConfig {
  development: {
    username: string;
    password: string;
    database: string;
    host: string;
    dialect: string;
    port: number;
  };
  test: {
    username: string;
    password: null;
    database: string;
    host: string;
    dialect: string;
    port: number;
  };
  production: {
    username: string;
    password: null;
    database: string;
    host: string;
    dialect: string;
    port: number;
  };
}

// Defina explicitamente o tipo para 'env'
const env: keyof DbConfig = (process.env.NODE_ENV || "development") as keyof DbConfig;

const dbConfig: DbConfig[typeof env] = config[env];

const pool = new Pool({
  user: dbConfig.username,
  host: dbConfig.host,
  database: dbConfig.database,
  password: dbConfig.password || undefined, // Lidar com null para password
  port: dbConfig.port,
});

// Função para conectar ao banco de dados
export async function connectToDatabase() {
  return pool.connect();
}

// Função para criar uma tabela para cada banco, se não existir
async function createTableIfNotExists(client: any, banco: string) {
  const tableName = `monitoramento_${banco.replace(/\s+/g, '_').toLowerCase()}`; // Criar um nome de tabela baseado no nome do banco
  
  const query = `
    CREATE TABLE IF NOT EXISTS ${tableName} (
      id SERIAL PRIMARY KEY,
      banco VARCHAR(255),
      status INT,
      duration INT,
      is_positive BOOLEAN,
      date TIMESTAMPTZ
    )
  `;
  
  await client.query(query);
}

// Função para salvar a resposta da API, criando a tabela, se necessário
export async function saveApiResponse(client: any, data: any) {
  const banco = data.banco;

  // Criar a tabela para o banco, se não existir
  await createTableIfNotExists(client, banco);

  const tableName = `monitoramento_${banco.replace(/\s+/g, '_').toLowerCase()}`; // Nome da tabela

  const query = `
    INSERT INTO ${tableName} (banco, status, duration, is_positive, date)
    VALUES ($1, $2, $3, $4, $5)
  `;
  const values = [data.banco, data.status, data.duration, data.isPositive, data.date];

  await client.query(query, values);
  // Remove client.release() from here
}


export async function logApiResponse(data: any) {
  const client = await connectToDatabase();
  await saveApiResponse(client, data);
  client.release(); // Liberar a conexão após salvar os dados
}
