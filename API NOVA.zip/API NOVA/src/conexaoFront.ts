import { connectToDatabase } from "./database";  // Função para conectar ao banco de dados
import { PoolClient } from "pg";  // Tipo para a conexão com o PostgreSQL
import moment from "moment";  // Para manipulação de datas (instale o Moment.js se necessário)

interface QueryParams {
  banco: string;     // Nome do banco
  periodo: string;   // Período para a consulta, ex: '24h', '7d', '1m'
}

export async function getBankData(params: QueryParams) {
  const { banco, periodo } = params;

  // Conectar ao banco de dados
  const client: PoolClient = await connectToDatabase();
  
  try {
    const tableName = `monitoramento_${banco.replace(/\s+/g, '_').toLowerCase()}`;

    // Obter a data inicial para o período baseado na string 'periodo' (por exemplo, '24h', '7d', '1m')
    let dateFilter: string;
    switch (periodo) {
      case "24h":
        dateFilter = moment().subtract(24, 'hours').format("YYYY-MM-DD HH:mm:ss");
        break;
      case "7d":
        dateFilter = moment().subtract(7, 'days').format("YYYY-MM-DD HH:mm:ss");
        break;
      case "1m":
        dateFilter = moment().subtract(1, 'months').format("YYYY-MM-DD HH:mm:ss");
        break;
      default:
        throw new Error("Período inválido");
    }

    // Consultar o banco de dados filtrando por banco e o período
    const query = `
      SELECT banco, status, duration, is_positive, date
      FROM ${tableName}
      WHERE date >= $1
      ORDER BY date DESC;
    `;
    
    const res = await client.query(query, [dateFilter]);

    // Verifica se encontrou algum dado
    if (res.rows.length === 0) {
      return { success: false, message: "Nenhum dado encontrado para o banco no período especificado." };
    }

    // Formatar os dados para retornar ao frontend
    const formattedData = res.rows.map(row => ({
      ...row,
      date: moment(row.date).format("YYYY/MM/DD HH:mm:ss")  // Formata a data no formato desejado
    }));

    // Retorna os dados encontrados
    return {
      success: true,
      data: formattedData
    };
  } catch (error) {
    console.error("Erro ao consultar dados:", error);
    return { success: false, message: "Erro ao consultar dados." };
  } finally {
    client.release();  // Libera a conexão com o banco de dados
  }
}
